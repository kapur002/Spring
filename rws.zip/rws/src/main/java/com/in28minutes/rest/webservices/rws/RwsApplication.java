package com.in28minutes.rest.webservices.rws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RwsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RwsApplication.class, args);
	}

}
