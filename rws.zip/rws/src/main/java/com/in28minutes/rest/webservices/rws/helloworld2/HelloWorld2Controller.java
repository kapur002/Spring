package com.in28minutes.rest.webservices.rws.helloworld2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld2Controller {

	@GetMapping(path="/rhw")
	public String returnHelloWorld() {
		return "Hello World 2";
	}
	
	@GetMapping(path="/hp")
	public String returnParth() {
		return "Hello Parth"; 
	}
}
