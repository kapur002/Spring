package com.in28minutes.rest.webservices.rws.user;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Component;

@Component
public class UserDaoService {
	
	private static List<User> users = new ArrayList<>();
	
	private static Integer userCount = 0;
	
	static {
		users.add(new User(++userCount, "Parth", LocalDate.now().minusYears(28)));
		users.add(new User(++userCount, "Suchi", LocalDate.now().minusYears(22)));
		users.add(new User(++userCount, "Karishma", LocalDate.now().minusYears(21)));
	}
	
	public List<User> findAll() {
		return users;
	}
	
	public User save(User user) {
		user.setId(++userCount);
		users.add(user);
		return user;
	}
	
	public User findOne(int id) {
		Predicate<? super User> predicate = user -> user.getId().equals(id);
		return users.stream().filter(predicate).findFirst().orElse(null);
	}
}
